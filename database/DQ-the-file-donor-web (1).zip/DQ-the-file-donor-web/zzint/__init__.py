import time

StartTime = time.time()
__version__ = 1.1